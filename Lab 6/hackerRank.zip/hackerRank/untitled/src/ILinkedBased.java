public interface ILinkedBased {
}
