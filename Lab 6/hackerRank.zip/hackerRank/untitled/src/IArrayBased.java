public interface IArrayBased {
}
